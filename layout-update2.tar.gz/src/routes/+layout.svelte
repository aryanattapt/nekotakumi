<script lang="ts">
	import '../app.css';
	let { children } = $props();

	let scrolled = $state(false);

	function handleScroll() {
		scrolled = window.scrollY > 300;
	}

	function scrollToTop() {
		window.scrollTo({ top: 0, behavior: 'smooth' });
	}
</script>

<svelte:window onscroll={handleScroll} />

<div class="layout">
	<header class="header">
		<div class="header-inner">
			<a href="/" class="logo">Nekotakumi</a>
			<nav>
				<a href="/">Blog</a>
				<a href="/news">Tech News</a>
			</nav>
		</div>
	</header>

	<main>
		{@render children()}
	</main>

	<footer class="footer">
		<p>Nekotakumi &copy; {new Date().getFullYear()}</p>
	</footer>
</div>

<button class="fab fab-top" class:visible={scrolled} aria-label="Scroll to top" onclick={scrollToTop}>
	<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="18 15 12 9 6 15"></polyline></svg>
</button>

<style>
	.layout {
		display: flex;
		flex-direction: column;
		min-height: 100vh;
	}

	.header {
		background: var(--bg-card);
		border-bottom: 1px solid var(--border);
		position: sticky;
		top: 0;
		z-index: 10;
		backdrop-filter: blur(8px);
		background: rgba(255,255,255,0.9);
	}

	.header-inner {
		max-width: var(--max-w);
		margin: 0 auto;
		padding: 1rem;
		display: flex;
		align-items: center;
		justify-content: space-between;
	}

	.logo {
		font-weight: 700;
		font-size: 1.25rem;
		color: var(--text) !important;
	}

	nav a {
		font-size: 0.9rem;
		font-weight: 500;
	}

	main {
		flex: 1;
	}

	.footer {
		text-align: center;
		padding: 2rem 1rem;
		color: var(--text-muted);
		font-size: 0.85rem;
		border-top: 1px solid var(--border);
		margin-top: 3rem;
	}

	.fab {
		position: fixed;
		bottom: 1.5rem;
		right: 1.5rem;
		width: 44px;
		height: 44px;
		border-radius: 50%;
		background: var(--accent);
		color: white;
		border: none;
		cursor: pointer;
		display: flex;
		align-items: center;
		justify-content: center;
		box-shadow: 0 4px 12px rgba(0,0,0,0.2);
		transition: opacity 0.3s, transform 0.3s;
		z-index: 50;
		opacity: 0;
		pointer-events: none;
	}

	.fab.visible {
		opacity: 1;
		pointer-events: auto;
	}

	.fab:hover {
		transform: scale(1.1);
		opacity: 0.9;
	}
</style>
