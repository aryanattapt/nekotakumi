import { pgTable, serial, text, timestamp, boolean } from 'drizzle-orm/pg-core';

export const posts = pgTable('posts', {
	id: serial('id').primaryKey(),
	title: text('title').notNull(),
	slug: text('slug').notNull().unique(),
	content: text('content').notNull(),
	excerpt: text('excerpt'),
	published: boolean('published').default(false).notNull(),
	createdAt: timestamp('created_at').defaultNow().notNull(),
	updatedAt: timestamp('updated_at').defaultNow().notNull()
});

export const news = pgTable('news', {
	id: serial('id').primaryKey(),
	title: text('title').notNull(),
	slug: text('slug').notNull().unique(),
	content: text('content').notNull(),
	excerpt: text('excerpt'),
	sourceUrl: text('source_url').notNull(),
	sourceName: text('source_name').notNull(),
	imageUrl: text('image_url'),
	publishedAt: timestamp('published_at').defaultNow().notNull(),
	createdAt: timestamp('created_at').defaultNow().notNull()
});
