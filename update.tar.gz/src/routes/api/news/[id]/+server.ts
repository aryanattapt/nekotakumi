import { json } from '@sveltejs/kit';
import { db } from '$lib/server/db';
import { news } from '$lib/server/db/schema';
import { eq } from 'drizzle-orm';

// GET /api/news/:id
export async function GET({ params }) {
	const id = parseInt(params.id);
	if (isNaN(id)) return json({ error: 'Invalid id' }, { status: 400 });

	const [item] = await db.select().from(news).where(eq(news.id, id)).limit(1);
	if (!item) return json({ error: 'Not found' }, { status: 404 });
	return json(item);
}

// DELETE /api/news/:id
export async function DELETE({ params }) {
	const id = parseInt(params.id);
	if (isNaN(id)) return json({ error: 'Invalid id' }, { status: 400 });

	const [item] = await db.delete(news).where(eq(news.id, id)).returning();
	if (!item) return json({ error: 'Not found' }, { status: 404 });
	return json({ message: 'Deleted', news: item });
}