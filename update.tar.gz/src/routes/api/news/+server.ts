import { json } from '@sveltejs/kit';
import { db } from '$lib/server/db';
import { news } from '$lib/server/db/schema';
import { eq } from 'drizzle-orm';

// GET /api/news — list all news (sorted by published_at desc)
export async function GET({ url }) {
	const slug = url.searchParams.get('slug');
	const limit = parseInt(url.searchParams.get('limit') || '50');
	
	if (slug) {
		const [item] = await db.select().from(news).where(eq(news.slug, slug)).limit(1);
		if (!item) return json({ error: 'Not found' }, { status: 404 });
		return json(item);
	}

	const all = await db.select().from(news).orderBy(news.publishedAt).limit(limit);
	return json(all);
}

// POST /api/news — create news entry
export async function POST({ request }) {
	const body = await request.json();
	const { title, slug, content, excerpt, sourceUrl, sourceName, imageUrl, publishedAt } = body;

	if (!title || !slug || !content || !sourceUrl || !sourceName) {
		return json({ error: 'title, slug, content, sourceUrl, sourceName required' }, { status: 400 });
	}

	// Check duplicate slug
	const [existing] = await db.select().from(news).where(eq(news.slug, slug)).limit(1);
	if (existing) {
		return json({ error: 'Duplicate slug' }, { status: 409 });
	}

	const [item] = await db.insert(news).values({
		title,
		slug,
		content,
		excerpt: excerpt || null,
		sourceUrl,
		sourceName,
		imageUrl: imageUrl || null,
		publishedAt: publishedAt ? new Date(publishedAt) : new Date()
	}).returning();

	return json(item, { status: 201 });
}