import { error } from '@sveltejs/kit';
import { db } from '$lib/server/db';
import { news } from '$lib/server/db/schema';
import { eq } from 'drizzle-orm';

export async function load({ params }) {
	const [item] = await db.select().from(news).where(eq(news.slug, params.slug)).limit(1);
	if (!item) error(404, 'News not found');
	return { news: item };
}