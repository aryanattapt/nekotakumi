<script lang="ts">
	let { data } = $props();
	let { news: item } = data;
</script>

<svelte:head>
	<title>{item.title} — Tech News Nekotakumi</title>
</svelte:head>

<div class="container">
	<article class="news-article">
		<header class="article-header">
			<div class="meta-row">
				<span class="source-badge">{item.sourceName}</span>
				<time>{new Date(item.publishedAt).toLocaleDateString('id-ID', { year: 'numeric', month: 'long', day: 'numeric' })}</time>
			</div>
			<h1>{item.title}</h1>
			{#if item.imageUrl}
				<img src={item.imageUrl} alt={item.title} class="featured-img" />
			{/if}
		</header>
		<div class="content">
			{@html item.content}
		</div>
		<div class="source-link">
			<a href={item.sourceUrl} target="_blank" rel="noopener noreferrer">
				Baca artikel asli di {item.sourceName} &nearr;
			</a>
		</div>
	</article>
	<div class="back-nav">
		<a href="/news" class="back-link">&larr; Kembali ke Tech News</a>
	</div>
</div>

<style>
	.container {
		max-width: var(--max-w);
		margin: 0 auto;
		padding: 2rem 1rem;
	}

	.news-article {
		background: var(--bg-card);
		border: 1px solid var(--border);
		border-radius: var(--radius);
		padding: 2rem;
	}

	.article-header {
		margin-bottom: 2rem;
		padding-bottom: 1.5rem;
		border-bottom: 1px solid var(--border);
	}

	.meta-row {
		display: flex;
		align-items: center;
		gap: 0.75rem;
		margin-bottom: 0.75rem;
	}

	.source-badge {
		display: inline-block;
		background: #dcfce7;
		color: #166534;
		font-size: 0.7rem;
		font-weight: 600;
		padding: 0.15rem 0.5rem;
		border-radius: 4px;
		text-transform: uppercase;
		letter-spacing: 0.05em;
	}

	.meta-row time {
		font-size: 0.8rem;
		color: var(--text-muted);
		text-transform: uppercase;
		letter-spacing: 0.05em;
	}

	.article-header h1 {
		font-size: 1.75rem;
		font-weight: 700;
		line-height: 1.3;
	}

	.featured-img {
		width: 100%;
		max-height: 400px;
		object-fit: cover;
		border-radius: var(--radius);
		margin-top: 1rem;
	}

	.content {
		font-size: 1.05rem;
		line-height: 1.8;
	}

	.content p {
		margin-bottom: 1.25rem;
	}

	.content h2 {
		font-size: 1.5rem;
		margin: 2rem 0 1rem;
	}

	.content h3 {
		font-size: 1.25rem;
		margin: 1.5rem 0 0.75rem;
	}

	.content ul, .content ol {
		margin: 1rem 0;
		padding-left: 1.5rem;
	}

	.content li {
		margin-bottom: 0.5rem;
	}

	.source-link {
		margin-top: 2rem;
		padding-top: 1.5rem;
		border-top: 1px solid var(--border);
		text-align: center;
	}

	.source-link a {
		display: inline-block;
		font-weight: 500;
		font-size: 0.95rem;
		color: var(--accent);
	}

	.source-link a:hover {
		text-decoration: underline;
	}

	.back-nav {
		margin-top: 2rem;
		text-align: center;
	}

	.back-link {
		font-weight: 500;
	}
</style>