<script lang="ts">
	import { onMount } from 'svelte';

	let items = $state([]);
	let loading = $state(true);

	onMount(async () => {
		const res = await fetch('/api/news?limit=50');
		items = await res.json();
		loading = false;
	});
</script>

<svelte:head>
	<title>Tech News — Nekotakumi</title>
</svelte:head>

<div class="hero">
	<h1>Tech News</h1>
	<p class="subtitle">Kumpulan berita teknologi terbaru — auto-clipped dari JagatReview</p>
</div>

<div class="container">
	{#if loading}
		<div class="loading">
			<div class="spinner"></div>
			<p>Memuat berita...</p>
		</div>
	{:else if items.length === 0}
		<div class="empty">
			<p>Belum ada berita.</p>
		</div>
	{:else}
		<div class="news-grid">
			{#each items as item}
				<article class="news-card">
					<div class="card-body">
						<div class="card-meta">
							<span class="source-badge">{item.sourceName}</span>
							<time>{new Date(item.publishedAt).toLocaleDateString('id-ID', { year: 'numeric', month: 'long', day: 'numeric' })}</time>
						</div>
						<h2><a href="/news/{item.slug}">{item.title}</a></h2>
						{#if item.excerpt}
							<p class="excerpt">{item.excerpt}</p>
						{/if}
					</div>
					<div class="card-footer">
						<a href="/news/{item.slug}" class="read-more">Baca selengkapnya &rarr;</a>
					</div>
				</article>
			{/each}
		</div>
	{/if}
</div>

<style>
	.hero {
		text-align: center;
		padding: 3rem 1rem 2rem;
		background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 50%, #f0fdf4 100%);
	}

	.hero h1 {
		font-size: 2.5rem;
		font-weight: 800;
		margin-bottom: 0.5rem;
		background: linear-gradient(135deg, #16a34a, #22c55e);
		-webkit-background-clip: text;
		-webkit-text-fill-color: transparent;
		background-clip: text;
	}

	.subtitle {
		color: var(--text-muted);
		font-size: 1rem;
	}

	.container {
		max-width: var(--max-w);
		margin: 0 auto;
		padding: 2rem 1rem;
	}

	.loading {
		text-align: center;
		padding: 3rem;
		color: var(--text-muted);
	}

	.spinner {
		width: 32px;
		height: 32px;
		border: 3px solid var(--border);
		border-top-color: var(--accent);
		border-radius: 50%;
		animation: spin 0.8s linear infinite;
		margin: 0 auto 1rem;
	}

	@keyframes spin { to { transform: rotate(360deg); } }

	.empty {
		text-align: center;
		padding: 3rem;
		color: var(--text-muted);
	}

	.news-grid {
		display: flex;
		flex-direction: column;
		gap: 1.25rem;
	}

	.news-card {
		background: var(--bg-card);
		border: 1px solid var(--border);
		border-radius: var(--radius);
		transition: box-shadow 0.2s, transform 0.2s;
		overflow: hidden;
	}

	.news-card:hover {
		box-shadow: 0 4px 12px rgba(0,0,0,0.08);
		transform: translateY(-2px);
	}

	.card-body {
		padding: 1.5rem 1.5rem 0.75rem;
	}

	.card-footer {
		padding: 0.75rem 1.5rem 1.25rem;
	}

	.card-meta {
		display: flex;
		align-items: center;
		gap: 0.75rem;
		margin-bottom: 0.5rem;
	}

	.source-badge {
		display: inline-block;
		background: #dcfce7;
		color: #166534;
		font-size: 0.7rem;
		font-weight: 600;
		padding: 0.15rem 0.5rem;
		border-radius: 4px;
		text-transform: uppercase;
		letter-spacing: 0.05em;
	}

	.card-meta time {
		font-size: 0.8rem;
		color: var(--text-muted);
		text-transform: uppercase;
		letter-spacing: 0.05em;
	}

	.news-card h2 {
		margin: 0.35rem 0;
		font-size: 1.2rem;
		line-height: 1.4;
	}

	.news-card h2 a {
		color: var(--text) !important;
	}

	.news-card h2 a:hover {
		color: var(--accent) !important;
	}

	.excerpt {
		color: var(--text-muted);
		font-size: 0.9rem;
		margin: 0.5rem 0 0;
		line-height: 1.5;
	}

	.read-more {
		font-size: 0.85rem;
		font-weight: 500;
	}
</style>