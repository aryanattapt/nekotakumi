<script lang="ts">
	import '../app.css';
	let { children } = $props();
</script>

<div class="layout">
	<header class="header">
		<div class="header-inner">
			<a href="/" class="logo">Nekotakumi</a>
			<nav>
				<a href="/">Blog</a>
				<a href="/news">Tech News</a>
			</nav>
		</div>
	</header>

	<main>
		{@render children()}
	</main>

	<footer class="footer">
		<p>Nekotakumi &copy; {new Date().getFullYear()}</p>
	</footer>
</div>

<style>
	.layout {
		display: flex;
		flex-direction: column;
		min-height: 100vh;
	}

	.header {
		background: var(--bg-card);
		border-bottom: 1px solid var(--border);
		position: sticky;
		top: 0;
		z-index: 10;
		backdrop-filter: blur(8px);
		background: rgba(255,255,255,0.9);
	}

	.header-inner {
		max-width: var(--max-w);
		margin: 0 auto;
		padding: 1rem;
		display: flex;
		align-items: center;
		justify-content: space-between;
	}

	.logo {
		font-weight: 700;
		font-size: 1.25rem;
		color: var(--text) !important;
	}

	nav a {
		font-size: 0.9rem;
		font-weight: 500;
	}

	main {
		flex: 1;
	}

	.footer {
		text-align: center;
		padding: 2rem 1rem;
		color: var(--text-muted);
		font-size: 0.85rem;
		border-top: 1px solid var(--border);
		margin-top: 3rem;
	}
</style>
